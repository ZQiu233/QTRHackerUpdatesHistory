# 这下面一大片是命名空间的导入，可以不管，照写就是
import clr
clr.AddReference("System")
clr.AddReference("QHackLib")
clr.AddReference("QTRHacker")
clr.AddReference("QTRHacker.Functions")
from System import *
from QTRHacker import *
from QTRHacker.Functions import *
from QHackLib import *
from QTRHacker.ScriptForm import Script

# 获得当前游戏的上下文环境
ctx = MainForm.Context
# 获得当前玩家(也就是被控制的玩家)
player = ctx.MyPlayer
# 获得Armor物品栏第10格，也就是时装的帽子
hat_vanity = player.Armor[10]
# 设置物品的类型，205是铁桶
hat_vanity.SetDefaults(205)
# 设置物品的数量
hat_vanity.Stack=99