# 这下面一大片是命名空间的导入，可以不管，照写就是
import clr
clr.AddReference("System")
clr.AddReference("QHackLib")
clr.AddReference("QTRHacker")
clr.AddReference("QTRHacker.Functions")
from System import *
from QTRHacker import *
from QTRHacker.Functions import *
from QHackLib import *
from QTRHacker.ScriptForm import Script

# 获得当前游戏的上下文环境
ctx = MainForm.Context
# 获得当前玩家(也就是被控制的玩家)
player = ctx.MyPlayer
# 在这个玩家的位置掉落物品，相当于给予物品
# 如果在别的玩家的坐标处掉落物品，那就相当于给予其他玩家物品，但这似乎还需要发送数据包，以后实现
Item.NewItem(ctx, player.X, player.Y, 0, 0, 3063, 1, False, 0, False, False)