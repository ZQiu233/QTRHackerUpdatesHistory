# 这下面一大片是命名空间的导入，可以不管，照写就是
import clr
clr.AddReference("System")
clr.AddReference("QHackLib")
clr.AddReference("QTRHacker")
clr.AddReference("QTRHacker.Functions")
from System import *
from QTRHacker import *
from QTRHacker.Functions import *
from QHackLib import *
from QTRHacker.ScriptForm import Script


inv = MainForm.Context.MyPlayer.Inventory
# 这是循环，从0到主背包最后一格的索引
# 然后获得物品的类型，输出
for i in range(Player.ITEM_MAX_COUNT):
	Script.WriteLine(str(i) + ": " + inv[i].Type.ToString())
