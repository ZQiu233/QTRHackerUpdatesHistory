import clr
clr.AddReference("System")
clr.AddReference("QHackLib")
clr.AddReference("QTRHacker")
clr.AddReference("QTRHacker.Functions")
from System import *
from QTRHacker import *
from QTRHacker.Functions import *
from QHackLib import *
from QTRHacker.ScriptForm import Script


player = MainForm.Context.MyPlayer
num = Item.NewItem(MainForm.Context, player.X + 200, player.Y, 0, 0, 3063, 1, False, 0, False, False)
NetMessage.SendData(MainForm.Context, 21, -1, -1, 0, num, 0, 0, 0, 0, 0, 0);